import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { User, Movie, Booking } from "./models.js";
import { sampleMovies } from "./data.js";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || "imovies-demo-secret";
app.use(cors({ origin: process.env.CLIENT_URL || true }));
app.use(express.json());

let dbOnline = false;
const demo = { users: [], movies: sampleMovies.map((m, i) => ({ ...m, _id: `movie-${i+1}`, createdAt: new Date().toISOString() })), bookings: [] };

const publicUser = u => ({ id: String(u._id), name: u.name, email: u.email, role: u.role });
const makeToken = u => jwt.sign({ id: String(u._id), role: u.role }, JWT_SECRET, { expiresIn: "7d" });
const safeMovie = m => ({ ...m, _id: String(m._id) });
const auth = async (req, res, next) => {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : "";
    if (!token) return res.status(401).json({ message: "Please log in to continue." });
    const payload = jwt.verify(token, JWT_SECRET);
    const user = dbOnline ? await User.findById(payload.id) : demo.users.find(u => String(u._id) === payload.id);
    if (!user) return res.status(401).json({ message: "Session expired. Please log in again." });
    req.user = user; next();
  } catch { return res.status(401).json({ message: "Invalid or expired session." }); }
};
const admin = (req, res, next) => req.user?.role === "admin" ? next() : res.status(403).json({ message: "Admin access required." });

async function seed() {
  if (dbOnline) {
    if (await Movie.countDocuments() === 0) await Movie.insertMany(sampleMovies);
    let a = await User.findOne({ email: "admin@imovies.com" });
    if (!a) await User.create({ name: "IMovies Admin", email: "admin@imovies.com", password: await bcrypt.hash("Admin@123", 10), role: "admin" });
  } else {
    if (!demo.users.some(u => u.email === "admin@imovies.com")) demo.users.push({ _id:"admin-demo", name:"IMovies Admin", email:"admin@imovies.com", password: await bcrypt.hash("Admin@123", 10), role:"admin" });
  }
}
app.get("/api/health", (req, res) => res.json({ status:"ok", database: dbOnline ? "MongoDB connected" : "demo memory mode", app:"IMovies API" }));

app.post("/api/auth/register", async (req, res) => {
  try {
    const { name, email, password } = req.body || {};
    if (!name?.trim() || !email?.trim() || !password || password.length < 6) return res.status(400).json({ message:"Enter your name, valid email, and a password of at least 6 characters." });
    const normalized = email.toLowerCase().trim();
    const exists = dbOnline ? await User.findOne({ email: normalized }) : demo.users.find(u => u.email === normalized);
    if (exists) return res.status(409).json({ message:"An account with this email already exists." });
    const user = { name:name.trim(), email:normalized, password:await bcrypt.hash(password,10), role:"user" };
    if (dbOnline) {
      const saved = await User.create(user);
      return res.status(201).json({ token:makeToken(saved), user:publicUser(saved) });
    }
    user._id = `user-${Date.now()}`; demo.users.push(user);
    res.status(201).json({ token:makeToken(user), user:publicUser(user) });
  } catch (e) { res.status(500).json({ message:"Could not create account.", detail:e.message }); }
});
app.post("/api/auth/login", async (req, res) => {
  try {
    const email = String(req.body?.email || "").toLowerCase().trim(), password = req.body?.password || "";
    const user = dbOnline ? await User.findOne({ email }) : demo.users.find(u => u.email === email);
    if (!user || !(await bcrypt.compare(password, user.password))) return res.status(401).json({ message:"Incorrect email or password." });
    res.json({ token:makeToken(user), user:publicUser(user) });
  } catch (e) { res.status(500).json({ message:"Could not log in.", detail:e.message }); }
});

app.get("/api/movies", async (req, res) => {
  try {
    let movies = dbOnline ? await Movie.find().sort({ createdAt:-1 }).lean() : demo.movies;
    const q = String(req.query.q || "").toLowerCase();
    const genre = String(req.query.genre || "All");
    movies = movies.filter(m => (!q || `${m.title} ${m.genre} ${m.language}`.toLowerCase().includes(q)) && (genre === "All" || m.genre === genre));
    res.json(movies.map(safeMovie));
  } catch { res.status(500).json({ message:"Could not load movies." }); }
});
app.get("/api/movies/:id", async (req, res) => {
  const m = dbOnline ? await Movie.findById(req.params.id).catch(()=>null) : demo.movies.find(x => x._id === req.params.id);
  if (!m) return res.status(404).json({ message:"Movie not found." });
  res.json(safeMovie(m.toObject ? m.toObject() : m));
});
app.post("/api/movies", auth, admin, async (req, res) => {
  try {
    const { title, genre, duration, rating, year, language, description, poster, price, showtimes } = req.body || {};
    if (!title?.trim()) return res.status(400).json({ message:"Movie title is required." });
    const movie = { title:title.trim(), genre:genre || "Drama", duration:duration || "2h 00m", rating:Number(rating)||7.5, year:Number(year)||new Date().getFullYear(), language:language||"Hindi", description:description||"", poster:poster||"", price:Math.max(1,Number(price)||180), showtimes:Array.isArray(showtimes)&&showtimes.length?showtimes:["10:30 AM","2:00 PM","6:30 PM"] };
    const saved = dbOnline ? await Movie.create(movie) : { ...movie, _id:`movie-${Date.now()}`, createdAt:new Date().toISOString() };
    if (!dbOnline) demo.movies.unshift(saved);
    res.status(201).json(safeMovie(saved.toObject ? saved.toObject() : saved));
  } catch (e) { res.status(500).json({ message:"Could not add movie.", detail:e.message }); }
});
app.delete("/api/movies/:id", auth, admin, async (req, res) => {
  try {
    if (dbOnline) await Movie.findByIdAndDelete(req.params.id);
    else demo.movies = demo.movies.filter(m => m._id !== req.params.id);
    res.json({ message:"Movie deleted." });
  } catch { res.status(500).json({ message:"Could not delete movie." }); }
});

app.get("/api/bookings/mine", auth, async (req, res) => {
  const rows = dbOnline
    ? await Booking.find({ user:req.user._id }).sort({ createdAt:-1 }).lean()
    : demo.bookings.filter(b => String(b.user) === String(req.user._id)).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  res.json(rows.map(b => ({ ...b, _id:String(b._id), movieTitle:b.movieTitle || "Movie" })));
});
app.post("/api/bookings", auth, async (req, res) => {
  try {
    const { movieId, date, showtime, seats } = req.body || {};
    if (!movieId || !date || !showtime || !Array.isArray(seats) || !seats.length) return res.status(400).json({ message:"Choose a date, showtime and at least one seat." });
    if (seats.length > 8) return res.status(400).json({ message:"You can book up to 8 seats at a time." });
    const movie = dbOnline ? await Movie.findById(movieId) : demo.movies.find(m => m._id === movieId);
    if (!movie) return res.status(404).json({ message:"Movie not found." });
    const occupied = dbOnline
      ? await Booking.find({ movie:movieId, date, showtime, status:"Confirmed" }).select("seats").lean()
      : demo.bookings.filter(b => b.movie === movieId && b.date === date && b.showtime === showtime && b.status === "Confirmed");
    const taken = new Set(occupied.flatMap(b => b.seats || []));
    const uniqueSeats = [...new Set(seats)];
    if (uniqueSeats.some(s => taken.has(s))) return res.status(409).json({ message:"One or more selected seats were just booked. Please choose again." });
    const row = { user:req.user._id, movie:movieId, movieTitle:movie.title, date, showtime, seats:uniqueSeats, total:uniqueSeats.length * movie.price, status:"Confirmed", createdAt:new Date().toISOString() };
    if (dbOnline) {
      const saved = await Booking.create(row);
      return res.status(201).json({ ...saved.toObject(), _id:String(saved._id), movieTitle:movie.title });
    }
    row._id = `booking-${Date.now()}`; demo.bookings.push(row);
    res.status(201).json(row);
  } catch (e) { res.status(500).json({ message:"Booking failed.", detail:e.message }); }
});
app.get("/api/bookings/occupied", async (req,res) => {
  const { movieId, date, showtime } = req.query;
  if (!movieId || !date || !showtime) return res.status(400).json({ message:"Movie, date and showtime are required." });
  const rows = dbOnline ? await Booking.find({ movie:movieId, date, showtime, status:"Confirmed" }).select("seats").lean() : demo.bookings.filter(b=>b.movie===movieId && b.date===date && b.showtime===showtime && b.status==="Confirmed");
  res.json([...new Set(rows.flatMap(b=>b.seats||[]))]);
});
app.get("/api/admin/summary", auth, admin, async (req,res) => {
  if (dbOnline) {
    const [movies, bookings, users, revenue] = await Promise.all([Movie.countDocuments(), Booking.countDocuments(), User.countDocuments({role:"user"}), Booking.aggregate([{ $match:{status:"Confirmed"} },{ $group:{_id:null,total:{$sum:"$total"}} }])]);
    const latest = await Booking.find().sort({createdAt:-1}).limit(8).lean();
    return res.json({ movies, bookings, users, revenue:revenue[0]?.total||0, latest:latest.map(b=>({...b,_id:String(b._id)})) });
  }
  res.json({ movies:demo.movies.length, bookings:demo.bookings.length, users:demo.users.filter(u=>u.role==="user").length, revenue:demo.bookings.reduce((n,b)=>n+b.total,0), latest:demo.bookings.slice(-8).reverse() });
});
app.get("/api/admin/bookings", auth, admin, async (req,res) => {
  if (dbOnline) {
    const rows = await Booking.find().sort({createdAt:-1}).limit(100).populate("user","name email").lean();
    return res.json(rows.map(b=>({...b,_id:String(b._id), customer:b.user?.name||"Customer", email:b.user?.email||""})));
  }
  res.json(demo.bookings.slice().reverse().map(b=>({...b,_id:String(b._id),customer:demo.users.find(u=>String(u._id)===String(b.user))?.name||"Customer",email:demo.users.find(u=>String(u._id)===String(b.user))?.email||""})));
});

async function start() {
  try {
    await mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/imovies", { serverSelectionTimeoutMS: 2500 });
    dbOnline = true;
    console.log("✅ MongoDB connected");
  } catch {
    dbOnline = false;
    console.log("ℹ️ MongoDB unavailable — starting in demo memory mode.");
  }
  await seed();
  app.listen(PORT, () => console.log(`🎬 IMovies API running at http://localhost:${PORT}`));
}
start();
